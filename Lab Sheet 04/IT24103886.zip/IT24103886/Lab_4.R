setwd("C:\\Users\\it24103886\\Desktop\\IT24103886")
branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
head(branch_data)
fix(data)
attach(data)

str(branch_data)


boxplot(branch_data$Sales_X1,main="Box plot for sales",ylab="sales")

fivenum(branch_data$Advertising_X2)

find_outliers<-function(x){
  q1<-quantile(x,0.25)
  q3<-quantile(x,0.75)
  IQR_value<-q3-q1
  lower<-q1-1.5*IQR_value
  upper<-q3+1.5*IQR_value
  outliers<-x[x<lower|x>upper]
  return(outliers)
}
